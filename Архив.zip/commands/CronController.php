<?php

namespace app\commands;

use app\Telegram\Service\Client;
use yii\console\Controller;

class CronController extends Controller
{

    // получить заказы
    public function actionOrders()
    {
        Client::textUlanenko('минута ' . date('H:i:s'));
    }


    // в час ночи
    public function actionOne()
    {

    }


    // в два ночи
    public function actionTwo()
    {

    }


}
