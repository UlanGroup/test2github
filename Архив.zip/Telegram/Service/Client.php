<?php

namespace app\Telegram\Service;

use app\Log\Entity\Error;
use app\User\Entity\User;
use Telegram\Bot\Api;


class Client
{
    const TOKEN = '6551751089:AAGdK_40Nk5zT0eB4JWBT6akn0spnFOp-7s';


    // новый юзер
    public static function new($token, $result)
    {
        Error::info('Telegram', $result);
        $fid = self::Fid($result);

//        $callback_id = self::CallbackId($result);
//        $message_id = self::MessageId($result);
//        $text = self::Text($result);

        Send::Text($token, $fid, "Привет!\n\nЯ бот UlanGroup!", null, null);
    }


    public static function textUlanenko($text)
    {
        Send::Text(self::TOKEN, 200783233, $text, null, null);// Уланенко
    }


    // Объявление размещено
    public static function done(int $user_id)
    {
        $text = "Объявление размещено";

        $fid = self::fidByUserId($user_id);
        if (!empty($fid)) {
            Send::Text(self::TOKEN, $fid, $text, null, null);
        } else {
            Error::error('TL done', 'нет fid ' . $user_id);
        }

        Send::Text(self::TOKEN, 406209800, $text, null, null);
    }






    // Вебхук
    // https://api.telegram.org/bot6551751089:AAGdK_40Nk5zT0eB4JWBT6akn0spnFOp-7s/setWebhook?url=https://api.ulangroup.ru/site/telegram
    // https://api.telegram.org/bot6551751089:AAGdK_40Nk5zT0eB4JWBT6akn0spnFOp-7s/getWebhookInfo
    public static function Webhook($token)
    {
        $telegram = new Api($token);
        return $telegram->setWebhook(['url' => 'https://api.ulangroup.ru/site/telegram']);
    }


    // FID (user_id из telegram)
    public static function Fid($result)
    {
        if (!empty($result->callback_query->message->chat->id)) {
            $fid = $result->callback_query->message->chat->id;
        } else {
            $fid = $result->message->chat->id;
        }
        return $fid;
    }


    public static function CallbackId($result)
    {
        if (!empty($result->callback_query)) {
            return $result->callback_query->id;
        }
    }


    public static function MessageId($result)
    {
        if (!empty($result->callback_query)) {
            return $result->callback_query->message->message_id;
        }
    }


    // Текст
    public static function Text($result)
    {
        if (!empty($result->callback_query)) {
            if (!empty($result->callback_query->message->text)) {
                return $result->callback_query->message->text;
            }
        } else {
            if (!empty($result->message->text)) {
                return $result->message->text;
            }
        }
    }



//    // Кнопки
//    public static function Call($result)
//    {
//        if (!empty($result->callback_query->data)) {
//            return Callback::Call(2, $result->callback_query->data);
//        }
//    }


    // найти fid
    public static function fidByUserId($user_id)
    {
        $profile = User::find()->where(['id' => $user_id])->one();
        if (!empty($profile) && !empty($profile->tl)) {
            return $profile->tl;
        }
        return null;
    }


    // найти профиль
    public static function Profile($fid)
    {
        return User::find()->where(['tl' => $fid])->one();
    }

}
