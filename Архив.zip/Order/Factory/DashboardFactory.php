<?php

namespace app\Order\Factory;

use app\Log\Entity\Error;
use app\Order\Entity\Dashboard;

class DashboardFactory
{

    // создать запись
    public function create(array $array): ?Dashboard
    {
        $dashboard = Dashboard::find()->where(['date' => $array['date']])->one();

        if (empty($dashboard)) {
            $dashboard = new Dashboard();
            $dashboard->date = $array['date'];
        }

        if (!empty($array['revenue'])) $dashboard->revenue = $array['revenue'];
        if (!empty($array['margin'])) $dashboard->margin = $array['margin'];
        if (!empty($array['solditems'])) $dashboard->solditems = $array['solditems'];
        if (!empty($array['average_check'])) $dashboard->average_check = $array['average_check'];
        if (!empty($array['returns'])) $dashboard->returns = $array['returns'];
        if (!$dashboard->save()) Error::error('dashboard->create', $dashboard->getErrors());

        return $dashboard;
    }
}

