<?php

namespace app\Order\Entity;


/**
 * This is the model class for table "dashboard_metrics".
 *
 * @property int $id
 * @property string $date
 * @property int $revenue
 * @property int $margin
 * @property int $solditems
 * @property int $average_check
 * @property int $turnover
 * @property int $returns
 * @property float $conversion_rate
 * @property int $marketing_expenses
 * @property float $customer_satisfaction
 * @property string $salesbycategory
 */
class Dashboard extends \yii\db\ActiveRecord
{

    public static function tableName()
    {
        return 'dashboard_metrics';
    }


    public function rules()
    {
        return [
            [['date', 'revenue'], 'required'],
            [['revenue', 'margin', 'solditems', 'average_check', 'turnover', 'returns', 'marketing_expenses'], 'integer'],
            [['conversion_rate', 'customer_satisfaction'], 'number'],
            [['salesbycategory'], 'string', 'max' => 255],
            [['date'], 'safe'],
        ];
    }
}
