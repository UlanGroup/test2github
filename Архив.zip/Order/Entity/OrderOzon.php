<?php

namespace app\Order\Entity;


/**
 * This is the model class for table "ozon_orders".
 *
 * @property int $id
 * @property int $order_id
 * @property string $created_at
 * @property string $city
 * @property string $delivery_type
 * @property int $is_premium
 * @property string $payment_type
 * @property string $region
 * @property int $warehouse_id
 * @property string $warehouse_name
 * @property string $order_number
 * @property string $posting_number
 * @property string $name
 * @property string $offer_id
 * @property float $price
 * @property int $qty
 * @property int $sku
 * @property string $status

 *
 * STATUS
 *
 * 1 awaiting_packaging — ожидает упаковки
 * 2 awaiting_deliver — ожидает отгрузки
 * 3 delivering — доставляется
 * 41 delivered — доставлено
 * 5 cancelled — отменено
 *
 */
class OrderOzon extends \yii\db\ActiveRecord
{

    public static function tableName()
    {
        return 'ozon_orders';
    }

    public function rules()
    {
        return [
            [[''], 'required'],
            [['order_id', 'is_premium', 'warehouse_id', 'qtl', 'sku'], 'integer'],
            [['price'], 'number'],
            [['city', 'delivery_type', 'payment_type', 'region', 'warehouse_name', 'order_number',
                'posting_number', 'name', 'offer_id', 'status'], 'string', 'max' => 255],
            [['created_at'], 'safe'],
        ];
    }


//    public function getTransactions()
//    {
//        return $this->hasMany(Transaction::class, ['order_id' => 'id']);
//    }
}
