<?php

namespace app\Order;

class Module extends \yii\base\Module
{

    public $controllerNamespace = 'app\Order\Controller';


    public $layout = '/main';


    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
