<?php

namespace app\controllers;

use app\Order\DTO\OrderDTO;
use app\Order\DTO\ProductDTO;

use app\Order\Entity\OrderOzon;
use app\Order\Entity\Product;
use app\Order\Factory\OrderFactory;
use app\Order\Factory\ProductFactory;
use app\Order\Factory\ProductStockFactory;

use app\Order\Service\DashboardService;
use app\Order\Service\OrderService;
use app\Service\CurlService;

use yii\web\Controller;

class ServiceController extends Controller
{

    // получить заказы от OZON
    public function actionOrdersOzon()
    {
        $result = CurlService::getOrders();
        if (empty($result)) return null;

        $productF = new ProductFactory();
        $orderF = new OrderFactory();

        foreach ($result['result'] as $item) {
            $productDTO = ProductDTO::ozon($item);
            $productF->create($productDTO);

            $orderDTO = OrderDTO::ozon($item);
            $orderF->create($orderDTO);
        }

        $orderS = new OrderService();
        $orderS->setProductId(); // привязать product_id к заказам
        $orderS->setCluster(); // привязать cluster к заказам

        return 'ok';
    }


    // получить остатки от OZON
    public function actionOzonStock()
    {
        $result = CurlService::getStock();

        $pwF = new ProductStockFactory();

        foreach ($result['result']['rows'] as $item) {
            $pwF->create($item);
        }
    }


    // получить товары от OZON
    public function actionProductsOzon()
    {
        $result = CurlService::getProducts();
        if (empty($result)) return null;

        $productF = new ProductFactory();

        foreach ($result['result']['items'] as $item) {
            $dto = ProductDTO::ozon($item);
            $productF->create($dto);
        }
    }


    // получить инфо об одном товаре от OZON
    public function actionProductOzon()
    {
        $result = CurlService::getProduct(100677855);
        if (empty($result)) return null;
        return $result;

        $productF = new ProductFactory();

        foreach ($result['result']['items'] as $item) {
            $dto = ProductDTO::ozon($item);
            $productF->create($dto);
        }
    }


    // пересчитать Dashboard вручную
    public function actionDashboard()
    {
        $dashboardS = new DashboardService();
        $dashboardS->reCount();
    }


    // TEST
    public function actionTest()
    {
        $srt = '2023-01-01';
        $end = '2024-01-01';

        // заказы
        $orders = OrderOzon::find()->select(['created_at', 'SUM(price) as revenue', 'SUM(qty) as solditems'])->groupBy('created_at')->asArray()->all();

        // возвраты
        $returns = OrderOzon::find()->select(['created_at', 'SUM(qty) as returns'])->where(['status' => 'cancelled'])->groupBy('created_at')->asArray()->all();

        // товары
        $products = Product::find()->all();

        $dashboard = [];
        while ($srt <= $end) {
            $row = ['date' => $srt];
            foreach ($orders as $order) {
                if ($order['created_at'] == $srt) {
                    $row['revenue'] = (int)$order['revenue'];
                    $row['solditems'] = (int)$order['solditems'];
                    $row['average_check'] = round($order['revenue'] / $order['solditems']);
                }
            }

            foreach ($returns as $return) {
                if ($return['created_at'] == $srt) {
                    $row['returns'] = (int)$return['returns'];
                }
            }

            $dashboard[] = $row;

            $srt = date('Y-m-d', strtotime("$srt +1 day"));
        }

        return $dashboard;
    }




    // НЕ НУЖНО

    // привязать product_id к заказу
    public function actionP()
    {
        $orderS = new OrderService();
        $orderS->setProductId();
    }


    // привязать кластер к заказу
    public function actionC()
    {
        $orderS = new OrderService();
        $orderS->setCluster();
    }


}
